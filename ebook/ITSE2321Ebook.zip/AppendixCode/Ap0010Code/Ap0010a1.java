/*File Ap0010a1.java Copyright, R.G.Baldwin

Instructions to student:
This program refuses to compile without errors.

Make the necessary corrections to cause the program to
compile and run successfully to produce the output shown
below:

ITSE
2321
**********************************************************/
public class Ap0010a1{
  public static void main(String args[]){
    System.out.println("ITSE");
    new Worker().doIt();
  }//end main()
}//end class definition 
//=======================================================//

Class Worker{
  public void doIt(){
    System.out.println("2321");
  }//end doIt()
}//end class definition
//=======================================================//

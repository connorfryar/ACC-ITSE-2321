/*File Ap0010h1.java Copyright, R.G.Baldwin

Instructions to student:
This program refuses to compile without errors.

Make the necessary corrections to cause the program to
compile and run successfully to produce the output shown
below:

false
**********************************************************/

public class Ap0010h1{
  public static void main(String args[]){
    new Worker().doIt();
  }//end main()
}//end class definition
//=======================================================//

class Worker{
  public void doIt(){
    boolean var;
    System.out.println(var);
  }//end doIt()
}//end class definition
//=======================================================//

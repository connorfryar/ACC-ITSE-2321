//3456789012345678901234567890123456789
class Q004_03{
  public static void main(
                        String args[]){
    byte size = 10;
    int[] array = new int[size];
    size = 20;
    System.out.println(array.length);    
  }//end main()
}//end class definition
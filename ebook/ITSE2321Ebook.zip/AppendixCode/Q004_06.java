//3456789012345678901234567890123456789
class Q004_06{
  public static void main(
                        String args[]){
    char[] a1 = {'\u0030','\u0031'};
    System.out.println(a1[1]);    
  }//end main()
}//end class definition
//3456789012345678901234567890123456789
class Q004_08{
  public static void main(
                        String args[]){
    char[] a1 = {'a','b','c','d'};
    System.out.println(a1[3] + " " +
                            a1.length);    
  }//end main()
}//end class definition
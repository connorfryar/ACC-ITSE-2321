//3456789012345678901234567890123456789
class Q005_03{
  public void main(String args[]){
    System.out.println("OK");
  }//end main()
}//end class definition
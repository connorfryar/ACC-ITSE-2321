//3456789012345678901234567890123456789

class Q107{
  public static void main(
                        String args[]){
    String x = new String("100");
    String y = new String("100");
    if(x == y) 
      System.out.println("Equal");
    else 
      System.out.println("Not Equal");
  }//end main()
}//end class definition
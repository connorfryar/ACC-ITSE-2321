//3456789012345678901234567890123456789

//File Q58.java
class Q58{
  public static void main(
                        String args[]){
    System.out.print(
                 Byte.MIN_VALUE + " ");
    System.out.println(Byte.MAX_VALUE);
  }//end main()
}//end class Q58
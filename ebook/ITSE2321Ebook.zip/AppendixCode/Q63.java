//3456789012345678901234567890123456789

//File Q63.java
class Q63{
  public static void main(
                        String args[]){
    int [] refToArray = {10, 11,};
    int var = 1;
    refToArray[var-1] = var = 2;
    System.out.println(refToArray[0] +
                  " " + refToArray[1]);
  }//end main()
}//end class Q63

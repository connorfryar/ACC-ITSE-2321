//3456789012345678901234567890123456789

//File Q64.java
class Q64{
  public static void main(
                        String args[]){
    int var1 = 10;
    int var2 = 20;
    System.out.println(
           var1 + var2++ + " " + var2);
  }//end main()
}//end class Q64

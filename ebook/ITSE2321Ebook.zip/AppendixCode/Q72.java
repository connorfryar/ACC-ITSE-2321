//3456789012345678901234567890123456789

//File Q72.java
class Q72{
  public static void main(
                        String args[]){
    byte x = -65;
    byte y = 2;
    byte z = (byte)(x * y);
    System.out.println(z);
  }//end main()
}//end class definition
//3456789012345678901234567890123456789

class Q74{
  public static void main(
                        String args[]){
    byte x = -64;
    byte y = -6;
    System.out.println(
                      x/y + " " + x%y);
  }//end main()
}//end class definition
//3456789012345678901234567890123456789

class Q75{
  public static void main(
                        String args[]){
    double x = 64.5;
    double y = 6.0;
    System.out.println(
                      x/y + " " + x%y);
  }//end main()
}//end class definition
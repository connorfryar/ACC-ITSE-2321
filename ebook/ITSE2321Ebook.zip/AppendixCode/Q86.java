//3456789012345678901234567890123456789

class Q86{
  public static void main(
                        String args[]){
    try{
      byte x = 32;
      byte y = (byte)(x << 2);
      System.out.println(y);
    }catch(Exception e){
      System.out.println("Exception");
    }//end catch
  }//end main()
}//end class definition
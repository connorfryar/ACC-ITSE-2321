//3456789012345678901234567890123456789

class Q90{
  public static void main(
                        String args[]){
    try{
      int x = -7;
      System.out.println(
                x/2 + " " + (x >> 1) );
    }catch(Exception e){
      System.out.println("Exception");
    }//end catch
  }//end main()
}//end class definition
//3456789012345678901234567890123456789

class Q94{
  public static void main(
                        String args[]){
    int x = 5;
    boolean y = true;
    System.out.println(x < y);
  }//end main()
}//end class definition
//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve &, < and > in the published version.
//======================================================//
//Revised 08/19/11

//File Memory01.java
class Memory01 { 
  public static void main(String[] args){
    int beans;
    beans = 25; 
    System.out.println(beans); 
  }//end main 
}//End Memory01 class

//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve &, < and > in the published version.
//======================================================//
//Revised 08/19/11

//File SqRt01.java
class SqRt01 { 
  public static void main(String[] args){
    double beans;
    beans = 25.5;
    double sqRtBns = Math.sqrt(beans);
    System.out.println(sqRtBns);
    double peas;
    peas = 36.;
    double sqRtPeas = Math.sqrt(peas);
    System.out.println(sqRtPeas); 
  }//end main 
}//End SqRt01 class

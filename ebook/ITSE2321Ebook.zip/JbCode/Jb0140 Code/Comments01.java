//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve &, < and > in the published version.
//======================================================//
//Revised 08/19/11

/*File Comments01.java
This is a multi-line comment.
*****************************************/
class Comments01 {
  //This is a single-line comment 
  public static void main(String[] args){ 
    System.out.println("Hello World"); 
  }//end main 
}//End class

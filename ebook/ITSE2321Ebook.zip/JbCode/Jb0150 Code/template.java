//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve &, < and > in the published version.
//======================================================//
//Revised 08/06/11

class template {
  public static void main(String[] args){
    System.out.println("Hello World");
  }
}

public interface Proj10X {
    // Method to get original data 
    int getData();
    
    // Method to get modified data
    int getModifiedData();
}
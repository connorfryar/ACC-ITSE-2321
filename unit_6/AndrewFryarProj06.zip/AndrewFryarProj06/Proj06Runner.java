/* File Proj06Runner
*****************************************************/

class Proj06Runner{
  
  static String var = "Andrew Connor Fryar";
  Proj06Runner(){
    System.out.println(
      "I certify that this program is my own work \n"+
      "and is not the work of others. I agree not \n" +
      "to share my solution with others."
    );
  }//end constructor

}//end class Proj06Runner


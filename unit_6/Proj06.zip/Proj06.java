/*File Proj06.java
The purpose of this assignment is to assess the student's
ability to write a program dealing with access to variables.
Revised 03/22/23 to correct a typo in the big comment.
***********************************************************/

// Student must not modify the code in this file. //

class Proj06{
  public static void main(String[] args){
    //Instantiate a new object of the student's class named
    // Proj06Runner. Store the object's reference in a
    // variable named obj of type Proj06Runner.
    Proj06Runner obj = new Proj06Runner();
    System.out.println(Proj06Runner.var);
  }//end main
}//end class Proj06
//End program specifications.
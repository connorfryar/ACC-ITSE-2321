public class Proj07Runner extends Proj07 {
    // Constructor
    public Proj07Runner() {
        // Display certification message
        System.out.println("I certify that this program is my own work");
        System.out.println("and is not the work of others. I agree not");
        System.out.println("to share my solution with others.");
    }
    
    // Override the run method from parent class Proj07
    @Override
    void run() {
        System.out.println("Andrew Connor Fryar\n");
    }
}
